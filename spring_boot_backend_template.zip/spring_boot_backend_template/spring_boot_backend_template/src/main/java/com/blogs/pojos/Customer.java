package com.blogs.pojos;
import java.util.List;
import java.util.ArrayList;
import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@ToString
@Entity
@Table(name = "customers")
public class Customer extends BaseEntity {

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)  // Foreign Key to User
    private User user;
    
    @OneToMany(mappedBy="customer" ,cascade=CascadeType.ALL)
    private List<Order>orders=new ArrayList<>();

    public Customer(User user) {
        this.user = user;
    }
    
   
}
