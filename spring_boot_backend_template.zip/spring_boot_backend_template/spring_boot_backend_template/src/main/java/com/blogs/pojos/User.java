package com.blogs.pojos;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@ToString
@Entity
@Table(name = "users")
public class User extends BaseEntity {

    @ManyToOne
    @JoinColumn(name = "role_id", nullable = false)  // Foreign Key for Role
    private Role role;

    @Column(name = "email", unique = true, nullable = false)
    private String email;

    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "contact_no", length = 15, nullable = false)
    private String contactNo;

    @Column(name = "is_deleted", nullable = false)
    private boolean isDeleted;

    @Column(name = "address")
    private String address;

    @Column(name = "updated_at")
    private String updatedAt;

    @Column(name = "first_name", nullable = false)
    private String firstName;

    @Column(name = "last_name", nullable = false)
    private String lastName;
}
