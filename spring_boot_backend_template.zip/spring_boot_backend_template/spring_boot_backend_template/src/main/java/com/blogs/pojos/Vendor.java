package com.blogs.pojos;
import java.util.List;
import java.util.ArrayList;
import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@ToString
@Entity
@Table(name = "vendors")
public class Vendor extends BaseEntity {

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)  // Foreign Key to User
    private User user;

    
    
    @Column(name = "business_name")
    private String businessName;

    @Column(name = "business_address")
    private String businessAddress;
    
    @OneToMany(mappedBy = "vendor", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Order> orders = new ArrayList<>();

    @OneToMany(mappedBy = "vendor", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<MenuItem> menuItems = new ArrayList<>();

    public Vendor(User user, String businessName, String businessAddress) {
        this.user = user;
        this.businessName = businessName;
        this.businessAddress = businessAddress;
    }
}
