package com.blogs.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blogs.dao.DeliveryPersonDao;
import com.blogs.dao.VendorDao;
import com.blogs.pojos.DeliveryPerson;
import com.blogs.pojos.Vendor;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class AdminServiceImpl implements AdminService{

	@Autowired
	VendorDao v;
	@Autowired
	DeliveryPersonDao d;
	
	@Override
	public String addVendor(Vendor vendor) {
	v.save(vendor);
	return "vendor is registered successfully";
	}

	@Override
	public String addDeliveryPerson(DeliveryPerson dp) {
		d.save(dp);
		return "delivery Person is registerd successfully";	 
	}
}
