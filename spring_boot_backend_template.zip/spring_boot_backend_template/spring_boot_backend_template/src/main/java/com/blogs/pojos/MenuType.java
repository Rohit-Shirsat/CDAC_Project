package com.blogs.pojos;

import java.util.List;
import java.util.ArrayList;
import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@ToString
@Entity
@Table(name = "menu_types")
public class MenuType extends BaseEntity {

    @Column(name = "name", nullable = false, unique = true)
    private String name;

    @Column(name = "description")
    private String description;

    @OneToMany(mappedBy="menuType", cascade=CascadeType.ALL,orphanRemoval=true)
    private List<MenuItem>menuitems=new ArrayList<>();
    
    public MenuType(String name, String description) {
        this.name = name;
        this.description = description;
    }
}
