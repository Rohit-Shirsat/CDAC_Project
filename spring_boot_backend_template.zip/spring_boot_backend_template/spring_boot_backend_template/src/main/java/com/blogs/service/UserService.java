package com.blogs.service;

import com.blogs.dtos.AuthDto;

public interface UserService {
  
	public String userAuthentication(AuthDto auth) throws Exception;
	
}
