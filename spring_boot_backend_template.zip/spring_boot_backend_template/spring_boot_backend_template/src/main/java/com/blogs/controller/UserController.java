package com.blogs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.blogs.dtos.AuthDto;
import com.blogs.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private  UserService users;
	
	@PostMapping("/SignIn")
	public String authentication(@RequestBody AuthDto auth) throws Exception {
		return users.userAuthentication(auth);
	}
	
	
}
