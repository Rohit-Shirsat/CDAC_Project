package com.blogs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.blogs.pojos.DeliveryPerson;
import com.blogs.pojos.Vendor;
import com.blogs.service.AdminService;

@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	AdminService admin;
	
	@PostMapping("/vendor")
	public String addVendor(Vendor v) {
		return admin.addVendor(v);
	}
	
	@PostMapping("/deliveryPerson")
	public String addDeliveryPerson(DeliveryPerson d) {
		return admin.addDeliveryPerson(d);
	}
	
}
