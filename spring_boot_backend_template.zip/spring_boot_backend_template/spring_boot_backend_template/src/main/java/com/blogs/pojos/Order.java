package com.blogs.pojos;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.List;
import java.util.ArrayList;
@Getter
@Setter
@NoArgsConstructor
@ToString
@Entity
@Table(name = "orders")
public class Order extends BaseEntity {

    @ManyToOne
    @JoinColumn(name = "customer_id", nullable = false)  // Foreign Key linking to Customer
    private Customer customer;

    @ManyToOne
    @JoinColumn(name = "vendor_id", nullable = false)  // Foreign Key linking to Vendor
    private Vendor vendor;

    @ManyToOne
    @JoinColumn(name = "dp_id", nullable = false)  // Foreign Key linking to DeliveryPerson
    private DeliveryPerson dp;

    @Column(name = "order_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date orderDate;

    @Column(name = "order_status", nullable = false)
    private String orderStatus;

    @OneToMany(mappedBy="order",cascade=CascadeType.ALL)
    private List<OrderItem>orderitems=new ArrayList<>();
    
    public Order(Customer customer, Vendor vendor, DeliveryPerson deliveryPerson, Date orderDate, String orderStatus) {
        this.customer = customer;
        this.vendor = vendor;
        this.dp = deliveryPerson;
        this.orderDate = orderDate;
        this.orderStatus = orderStatus;
    }
}
