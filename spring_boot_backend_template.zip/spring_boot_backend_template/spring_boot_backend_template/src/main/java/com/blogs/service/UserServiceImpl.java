package com.blogs.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blogs.dao.Userdao;
import com.blogs.dtos.AuthDto;
import com.blogs.pojos.User;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UserServiceImpl implements UserService{
    @Autowired
	Userdao user;
	@Override
	public String userAuthentication(AuthDto auth) throws Exception {
		  
		String Email=auth.getEmail();
		String Password=auth.getPassword();
	    User userEntity=user.findByEmailAndPassword(Email, Password).orElseThrow(()->
	    	new Exception("Invalid Email or Password")
	    );
		
		return "Authenticated Successfully";
	}
   
}
