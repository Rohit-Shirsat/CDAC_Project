package com.blogs.service;

import com.blogs.pojos.DeliveryPerson;
import com.blogs.pojos.Vendor;

public interface AdminService {

	public String addVendor(Vendor vendor);
	
	public String addDeliveryPerson(DeliveryPerson dp);
}