package com.blogs.pojos;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@ToString
@Entity
@Table(name = "order_items")
public class OrderItem extends BaseEntity {

    @ManyToOne
    @JoinColumn(name = "order_id", nullable = false)  // Foreign Key linking to Order
    private Order order;

    @ManyToOne
    @JoinColumn(name = "menu_item_id", nullable = false)  // Foreign Key linking to MenuItem
    private MenuItem menuItem;

    @Column(name = "quantity", nullable = false)
    private int quantity;

    public OrderItem(Order order, MenuItem menuItem, int quantity) {
        this.order = order;
        this.menuItem = menuItem;
        this.quantity = quantity;
    }
}
