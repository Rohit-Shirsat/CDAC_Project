package com.blogs.pojos;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@ToString
@Entity
@Table(name = "menu_items")
public class MenuItem extends BaseEntity {

    @ManyToOne
    @JoinColumn(name = "vendor_id", nullable = false)  // Foreign Key linking to Vendor
    private Vendor vendor;

    @ManyToOne
    @JoinColumn(name = "menu_type_id", nullable = false)  // Foreign Key linking to MenuType
    private MenuType menuType;

    private String name;
    
    @Lob
    private byte[] image;

    @Column(name = "availability", nullable = false)
    private boolean availability;

    @Column(name = "price", nullable = false)
    private float price;

    public MenuItem(Vendor vendor, MenuType menuType, byte[] image, boolean availability, float price,String name) {
        this.vendor = vendor;
        this.menuType = menuType;
        this.image = image;
        this.availability = availability;
        this.price = price;
        this.name=name;
    }
}
