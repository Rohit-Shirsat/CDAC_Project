export function Home(){


return(

    <div>
        <h1>In Home page</h1>
    </div>
)

}
export default Home;